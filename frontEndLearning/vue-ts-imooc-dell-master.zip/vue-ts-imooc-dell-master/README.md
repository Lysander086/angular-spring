
# front-vue
慕课网dell老师  Vue + ts版。 

[TypeScript －系统入门到项目实战](https://coding.imooc.com/class/412.html)

![echarts supported](https://img.shields.io/badge/echarts-%5E4.6.0-brightgreen) ![vue supported](https://img.shields.io/badge/vue-%5E2.6.11-brightgreen) ![typescript supported](https://img.shields.io/badge/typescript-~3.7.5-blue)

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
