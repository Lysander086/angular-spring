package thirdpart.checksum;

public interface IChecksum {
    byte getChecksum(byte[] data);
}
