package thirdpart.fetchsurv;

import thirdpart.order.OrderCmd;

import java.util.List;

public interface IFetchService {

    List<OrderCmd> fetchData();

}
