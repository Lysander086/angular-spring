package thirdpart.checksum;

public interface ICheckSum {

    byte getChecksum(byte[] data);

}
