export const config = {

    //后台服务地址
    real_domain: "http://localhost:8090"


}